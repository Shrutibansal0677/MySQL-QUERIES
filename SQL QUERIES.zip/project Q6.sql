#total revenue in 2020 in chennai
SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where (date.year=2020 and transactions.market_code="Mark001") and (transactions.currency="INR" or transactions.currency="USD");
	 