SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where date.year=2020 and (transactions.currency="INR" or transactions.currency="USD");
	 