SELECT *  
FROM transactions 
INNER JOIN date
ON transactions.order_date = date.date
where date.year= "2020"
