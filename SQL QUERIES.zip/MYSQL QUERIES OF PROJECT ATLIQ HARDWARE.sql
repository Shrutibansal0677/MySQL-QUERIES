# to find nu of transactions in the year 2020
SELECT *  
FROM transactions 
INNER JOIN date
ON transactions.order_date = date.date
where date.year= "2020";


# to find transactions in the market chennai with market_code="Mark001"
select count(distinct product_code) 
from transactions
where market_code="Mark001";


#to find sum of sales_amount that is revenue in year 2020
SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where date.year=2020 and (transactions.currency="INR" or transactions.currency="USD");
 
 
 
 #total revenue in 2020jan
SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where (date.year=2020 and date.month_name= "January" ) and (transactions.currency="INR" or transactions.currency="USD");
 
 
 
 #total revenue in 2020 in chennai
SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where (date.year=2020 and transactions.market_code="Mark001") and (transactions.currency="INR" or transactions.currency="USD");
 
 
 
	 
 
 
