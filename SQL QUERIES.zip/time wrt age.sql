select sum(session.Duration), profile.age 
from 
profile
left join session
using (`User ID`)
group by profile.age 
order by sum(session.Duration) desc
