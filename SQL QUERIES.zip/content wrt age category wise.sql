select count(content.Type) AS COUNT_OF_CONTENT, profile.age ,  content.Category
from 
content
 join profile
using (`User ID`)
where age < 30
group by profile.age , content.Category
order by   count(content.Type) desc
