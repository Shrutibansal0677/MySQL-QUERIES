/* mobile used by particular set of people */

select count(profile.age), session.Device 
from 
session
left join profile
using (`User ID`)
WHERE 20<AGE
group by session.Device
