#total revenue in 2020jan
SELECT SUM(transactions.sales_amount)
 FROM transactions 
 INNER JOIN date 
 ON transactions.order_date=date.date 
 where (date.year=2020 and date.month_name= "January" ) and (transactions.currency="INR" or transactions.currency="USD");
	 