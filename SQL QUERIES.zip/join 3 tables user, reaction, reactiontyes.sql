select * 
from 
profile
join reactions
using (`user Id`)
join reactiontypes
on 
reactions.Type= reactiontypes.Type