select  reactions.Type, count(reactiontypes.Sentiment) as sentiment_count , sum(reactiontypes.Score) as sum,  profile.age, profile.Interests
from reactions
join reactiontypes
using ( Type )
join profile
using (`User id`)
group by profile.Interests, profile.Age, reactions.Type
order by sum desc


