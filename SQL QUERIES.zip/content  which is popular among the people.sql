/* content / interest  which is popular among the people
popular- score
content reaction reactiontypes */

select content.Type, sum(Score) as famous, content.Category
from reactions
join reactiontypes
using ( type ) 
join content
using (`content id`)
group by content.Type, content.Category
