select count(distinct product_code) 
from transactions
where market_code="Mark001"